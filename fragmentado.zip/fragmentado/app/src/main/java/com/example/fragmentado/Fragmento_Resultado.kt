package com.example.fragmentado

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_fragmento__resultado.*

/**
 * A simple [Fragment] subclass.
 */
class Fragmento_Resultado : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragmento__resultado, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        val guadou = arguments?.getDouble("guadou")
        val gastou = arguments?.getDouble("gastou")

        if (gastou!! > guadou!!){
            txt_result.text = "Você está na pindaíba"
            image_result.setImageDrawable(context?.getDrawable(R.drawable.ash_sad))
        }
        else{
            txt_result.text = "Você ainda tem grana!"
            image_result.setImageDrawable(context?.getDrawable(R.drawable.happy_ash))
        }

    }

}
