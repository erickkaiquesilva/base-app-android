package com.example.fragmentado

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun mostrarFragmento1(v:View){
        supportFragmentManager.beginTransaction().replace(R.id.frame_layout, Fragmento_1()).commit()
    }

    fun mostrarFragmento2(v:View){

        val parametros = Bundle()
        parametros.putString("bairro", "Perus")
        parametros.putInt("habitantes", 10000)

        val fragmento2 = Fragmento_2()
        fragmento2.arguments = parametros

        supportFragmentManager.beginTransaction().replace(R.id.frame_layout, fragmento2).commit()
    }

    fun quantoTem(v:View){

        val parametro = Bundle()

        parametro.putDouble("guadou", et_guadou.text.toString().toDouble())
        parametro.putDouble("gastou", et_gastou.text.toString().toDouble())

        val resultado = Fragmento_Resultado()
        resultado.arguments = parametro

        supportFragmentManager.beginTransaction().replace(R.id.frame_layout, resultado).commit()
    }
}
